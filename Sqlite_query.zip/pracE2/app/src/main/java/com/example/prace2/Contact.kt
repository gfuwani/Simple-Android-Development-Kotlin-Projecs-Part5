package com.example.prace2

data class Contact(
    val id: Int,
    val name: String,
    val phone: String
)