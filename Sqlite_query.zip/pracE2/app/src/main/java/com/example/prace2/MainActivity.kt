package com.example.prace2

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.widget.SearchView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var btInsert: Button
    private lateinit var btReset: Button
    private lateinit var listView: ListView
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: ContactAdapter
    private var contactCounter= 1
    private lateinit var searchView: SearchView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupDatabase()
        setupListeners()
        displayAllData()
    }

    private fun initializeViews(){
        btInsert= findViewById(R.id.btInsert)
        btReset= findViewById(R.id.btReset)
        listView= findViewById(R.id.lv)

    }

    private fun setupDatabase(){
        dbHelper= DatabaseHelper(this)

        if(dbHelper.getContactsCount()==0){
            dbHelper.insertDefaultContact()
            contactCounter= 6
        } else {
            contactCounter= dbHelper.getContactsCount()+1
        }
    }

    private fun setupListeners(){
        btInsert.setOnClickListener {
            insertRandomData()
        }

        btReset.setOnClickListener {
            resetData()
        }

        listView.setOnItemClickListener{ parent, view, position, id ->
            val contact= adapter.getItem(position) as Contact
            Toast.makeText(this, "Selected: ${contact.name}", Toast.LENGTH_SHORT).show()
        }

    }

    private fun insertRandomData(){
        val phoneNumber= String.format(
            Locale.getDefault(),
            "%03d-%04d",
            Random.nextInt(1000),
            Random.nextInt(10000)
        )

        val contactName= "Task $contactCounter"

        dbHelper.insertContact(contactName, phoneNumber)
        contactCounter++

        updateListView()

        Toast.makeText(this, "Data inserted successfully", Toast.LENGTH_SHORT).show()
    }

    private fun resetData(){
        dbHelper.resetTable()

        dbHelper.insertDefaultContact()
        contactCounter= 6

        updateListView()

        Toast.makeText(this, "Data reset successfully", Toast.LENGTH_SHORT).show()
    }

    private fun displayAllData(){
        val contacts= dbHelper.getAllContacts()
        adapter= ContactAdapter(this, contacts)
        listView.adapter= adapter

        supportActionBar?.title= "Contacts ${contacts.size}"
    }

    private fun searchData(query: String){
        val contacts= if(query.isBlank()){
            dbHelper.getAllContacts()
        } else{
            dbHelper.searchContacts(query)
        }

        adapter= ContactAdapter(this, contacts)
        listView.adapter= adapter

        supportActionBar?.subtitle= if(query.isNotBlank()){
            "Search: '$query' (${contacts.size} results)"
        } else{
            "All contacts (${contacts.size})"
        }

    }

    private fun updateListView(){
        val currentQuery= if(::searchView.isInitialized){
            searchView.query.toString()
        } else{
            ""
        }

        if(currentQuery.isBlank()){
            displayAllData()
        } else{
            searchData(currentQuery)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.opt_menu, menu)
        val searchItem= menu.findItem(R.id.action_search)
        searchView= searchItem.actionView as SearchView

        searchView.queryHint= "Search by name or phone"
        searchView.maxWidth= Integer.MAX_VALUE

        searchView.setOnQueryTextListener(object: SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String): Boolean {
                searchData(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                searchData(newText)
                return true
            }
        })

        searchItem.setOnActionExpandListener(object: MenuItem.OnActionExpandListener{
            override fun onMenuItemActionExpand(item: MenuItem): Boolean {
                return true
            }

            override fun onMenuItemActionCollapse(item: MenuItem): Boolean {
                displayAllData()
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.action_search->{
                true
            }else ->{
                super.onOptionsItemSelected(item)
            }
        }
    }
}