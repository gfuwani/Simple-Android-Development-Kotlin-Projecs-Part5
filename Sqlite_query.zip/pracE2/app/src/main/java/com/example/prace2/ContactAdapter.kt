package com.example.prace2

import android.content.Context
import android.text.Highlights
import android.text.SpannableString
import android.text.Spanned
import android.text.SpannedString
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import java.time.temporal.TemporalQuery

class ContactAdapter(context: Context, private val contacts: List<Contact>, private var searchQuery: String= ""):
    ArrayAdapter<Contact>(context, R.layout.row_view, contacts){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view= convertView
        var viewHolder: ViewHolder

        if(view==null){
            view= LayoutInflater.from(context).inflate(R.layout.row_view, parent, false)
            viewHolder= ViewHolder(view)
            view.tag= viewHolder
        } else{
            viewHolder= view.tag as ViewHolder
        }

        val contact= contacts[position]

        if(searchQuery.isNotBlank()){
            viewHolder.nameTV.text= highLightText(contact.name, searchQuery)
            viewHolder.phoneTV.text= highLightText(contact.phone, searchQuery)
        } else{
            viewHolder.nameTV.text= contact.name
            viewHolder.phoneTV.text= contact.phone
        }
        return view!!
    }

    private fun highLightText(text: String, query: String): CharSequence{
        if(query.isBlank()) return text

        val spannableString= SpannableString(text)
        val lowerText= text.lowercase()
        val lowerQuery= query.lowercase()

        var startIndex= 0
        while (startIndex < lowerText.length){
            val matchIndex = lowerText.indexOf(lowerQuery, startIndex)
            if (matchIndex== -1) break

            val color= ContextCompat.getColor(context, android.R.color.holo_blue_bright)
            spannableString.setSpan(
                ForegroundColorSpan(color),
                matchIndex,
                matchIndex+query.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            startIndex= matchIndex+query.length
        }
        return spannableString
    }

    fun updateSearchQuery(query: String){
        searchQuery= query
        notifyDataSetChanged()
    }

    public class ViewHolder(view: View){
        val nameTV: TextView= view.findViewById(R.id.tvName)
        val phoneTV: TextView= view.findViewById(R.id.tvPhone)
    }
}