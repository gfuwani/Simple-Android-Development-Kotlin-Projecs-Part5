package com.example.prace3

import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: ContactAdapter
    private var searchView: SearchView? = null
    private var selectedContactId: Int = -1
    private var selectedPosition: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupDatabase()
        setupListeners()
        displayAllData()
    }

    private fun initializeViews() {
        listView = findViewById(R.id.lv)

        registerForContextMenu(listView)
    }

    private fun setupDatabase() {
        dbHelper = DatabaseHelper(this)

        if (dbHelper.isDatabaseEmpty()) {
            dbHelper.resetDatabase()
        }
    }

    private fun setupListeners() {
        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val contact = adapter.getItem(position) as Contact
            Toast.makeText(
                this,
                "Selected: ${contact.name} - ${contact.phone}",
                Toast.LENGTH_SHORT
            ).show()
        }

        listView.setOnItemLongClickListener { parent, view, position, id ->
            selectedPosition = position
            false
        }
    }

    private fun displayAllData() {
        val contacts = dbHelper.getAllContacts()
        adapter = ContactAdapter(this, contacts)
        listView.adapter = adapter

        supportActionBar?.title = "Contacts (${contacts.size})"
        supportActionBar?.subtitle = null
    }

    private fun searchData(query: String) {
        val contacts = if (query.isBlank()) {
            dbHelper.getAllContacts()
        } else {
            dbHelper.searchContacts(query)
        }

        adapter = ContactAdapter(this, contacts)
        listView.adapter = adapter

        supportActionBar?.subtitle = if (query.isNotBlank()) {
            "Search: '$query' (${contacts.size} results)"
        } else {
            null
        }
    }

    private fun showContactDialog(contactId: Int = -1, isNew: Boolean = true) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_contact, null)
        val etName = dialogView.findViewById<EditText>(R.id.etName)
        val etPhone = dialogView.findViewById<EditText>(R.id.etPhone)

        val title: String
        if (isNew) {
            title = "Add New Contact"
        } else {
            title = "Modify Contact"
            val contact = dbHelper.getContactById(contactId)
            contact?.let {
                etName.setText(it.name)
                etPhone.setText(it.phone)
            } ?: run {
                Toast.makeText(this, "Contact not found", Toast.LENGTH_SHORT).show()
                return
            }
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton("Save") { dialog, which ->
                val name = etName.text.toString().trim()
                val phone = etPhone.text.toString().trim()

                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (isNew) {
                    val result = dbHelper.insertContact(name, phone)
                    if (result != -1L) {
                        Toast.makeText(this, "Contact added successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Failed to add contact", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val result = dbHelper.updateContact(contactId, name, phone)
                    if (result > 0) {
                        Toast.makeText(this, "Contact updated successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Failed to update contact", Toast.LENGTH_SHORT).show()
                    }
                }

                updateListView()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateListView() {
        val currentQuery = searchView?.query?.toString() ?: ""

        if (currentQuery.isBlank()) {
            displayAllData()
        } else {
            searchData(currentQuery)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.opt_menu, menu)

        val searchItem = menu.findItem(R.id.opt_search)
        searchView = searchItem.actionView as? SearchView

        searchView?.let {
            it.queryHint = "Search by name or phone..."
            it.maxWidth = Integer.MAX_VALUE

            it.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String): Boolean {
                    searchData(query)
                    return true
                }

                override fun onQueryTextChange(newText: String): Boolean {
                    searchData(newText)
                    return true
                }
            })

            searchItem.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
                override fun onMenuItemActionExpand(item: MenuItem): Boolean {
                    return true
                }

                override fun onMenuItemActionCollapse(item: MenuItem): Boolean {
                    displayAllData()
                    return true
                }
            })
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.opt_new -> {
                showContactDialog(isNew = true)
                true
            }
            R.id.opt_reset -> {
                AlertDialog.Builder(this)
                    .setTitle("Reset Database")
                    .setMessage("Are you sure you want to reset all contacts?")
                    .setPositiveButton("Yes") { dialog, which ->
                        dbHelper.resetDatabase()
                        updateListView()
                        Toast.makeText(this, "Database reset successfully", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("No", null)
                    .show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.ctx_menu, menu)

        if (selectedPosition != -1 && adapter.count > selectedPosition) {
            val contact = adapter.getItem(selectedPosition) as? Contact
            contact?.let {
                selectedContactId = it.id
                menu?.setHeaderTitle("${it.name}")
            }
        }
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.ctx_modify -> {
                if (selectedContactId != -1) {
                    showContactDialog(selectedContactId, isNew = false)
                }
                true
            }
            R.id.ctx_delete -> {
                if (selectedContactId != -1) {
                    AlertDialog.Builder(this)
                        .setTitle("Delete Contact")
                        .setMessage("Are you sure you want to delete this contact?")
                        .setPositiveButton("Yes") { dialog, which ->
                            val result = dbHelper.deleteContact(selectedContactId)
                            if (result > 0) {
                                Toast.makeText(this, "Contact deleted successfully", Toast.LENGTH_SHORT).show()
                                updateListView()
                            }
                        }
                        .setNegativeButton("No", null)
                        .show()
                }
                true
            }
            R.id.ctx_new -> {
                showContactDialog(isNew = true)
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        selectedPosition = -1
        selectedContactId = -1
    }
}