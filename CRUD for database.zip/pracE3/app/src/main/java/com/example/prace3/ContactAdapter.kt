package com.example.prace3

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class ContactAdapter(context: Context, private val contacts: List<Contact>) :
    ArrayAdapter<Contact>(context, R.layout.row_view, contacts) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        val viewHolder: ViewHolder

        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.row_view, parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        } else {
            viewHolder = view.tag as ViewHolder
        }

        val contact = contacts[position]
        viewHolder.nameTextView.text = contact.name
        viewHolder.phoneTextView.text = contact.phone

        // Store contact ID as tag for context menu
        view?.setTag(R.id.contact_id_tag, contact.id)

        return view!!
    }

    override fun getItemId(position: Int): Long {
        return contacts[position].id.toLong()
    }

    private class ViewHolder(view: View) {
        val nameTextView: TextView = view.findViewById(R.id.tvName)
        val phoneTextView: TextView = view.findViewById(R.id.tvPhone)
    }
}


val contact_id_tag = 1001