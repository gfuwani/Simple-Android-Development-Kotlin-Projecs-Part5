package com.example.prace1

import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var btInsert: Button
    private lateinit var btReset: Button
    private lateinit var listView: ListView
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: ContactAdapter
    private var contactCounter= 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initializeViews()
        setupDatabase()
        setupListeners()
        displayData()
    }

    private fun initializeViews(){
        btInsert= findViewById(R.id.btInsert)
        btReset= findViewById(R.id.btReset)
        listView= findViewById(R.id.lv)
    }

    private fun setupDatabase(){
        dbHelper= DatabaseHelper(this)

        if(dbHelper.getAllContacts().isEmpty){
            dbHelper.insertDefaultContact()
            contactCounter= 1
        } else{
            contactCounter= dbHelper.getAllContacts().size+1
        }
    }

    private fun setupListeners(){
        btInsert.setOnClickListener {
            insertRandomData()
        }

        btReset.setOnClickListener {
            resetData()
        }
    }

    private fun insertRandomData(){
        val phoneNumber= String.format(
            Locale.getDefault(),
            "%03d-%04d",
            Random.nextInt(1000),
            Random.nextInt(10000)
        )

        val contactName= "Task $contactCounter"

        dbHelper.insertContact(contactName, phoneNumber)
        contactCounter++

        displayData()

        Toast.makeText(this,"Data inserted successfuly", Toast.LENGTH_SHORT).show()
    }

    private fun resetData(){
        dbHelper.resetTable()

        dbHelper.insertDefaultContact()
        contactCounter= 2

        displayData()

        Toast.makeText(this,"Data reset successfully", Toast.LENGTH_SHORT).show()
    }

    private fun displayData(){
        val contacts= dbHelper.getAllContacts()
        adapter= ContactAdapter(this, contacts)
        listView.adapter= adapter
    }
}