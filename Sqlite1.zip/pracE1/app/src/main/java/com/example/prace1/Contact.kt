package com.example.prace1

data class Contact(
    val id: Int,
    val name: String,
    val phone: String
)
