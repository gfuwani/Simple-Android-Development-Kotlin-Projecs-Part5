package com.example.prace1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class ContactAdapter(context: Context, private val contacts: List<Contact>):
    ArrayAdapter<Contact>(context, R.layout.row_view, contacts){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view= convertView
        var viewHolder: ViewHolder


        if(view==null){
            view= LayoutInflater.from(context).inflate(R.layout.row_view, parent, false)
            viewHolder= ViewHolder(view)
            view.tag= viewHolder
        } else{
            viewHolder= view.tag as ViewHolder
        }

        val contact= contacts[position]
        viewHolder.nameTextview.text= contact.name
        viewHolder.phoneTextView.text= contact.phone

        return view
    }

    private class ViewHolder(view: View){
        val nameTextview: TextView = view.findViewById(R.id.tvName)
        val phoneTextView: TextView= view.findViewById(R.id.tvPhone)
    }
}